# CatsDogsDetetion > 2023-06-20 8:19pm
https://universe.roboflow.com/viso-computacional-yolov8/catsdogsdetetion

Provided by a Roboflow user
License: CC BY 4.0

