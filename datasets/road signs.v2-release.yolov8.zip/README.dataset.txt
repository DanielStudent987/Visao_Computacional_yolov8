# road signs > release
https://universe.roboflow.com/roboflow-100/road-signs-6ih4y

Provided by a Roboflow user
License: CC BY 4.0

This dataset was originally created by [王天裔 (Wang Tianyi)](https://universe.roboflow.com/project-sign-detection/). To see the current project, which may have been updated since this version, please go here: https://universe.roboflow.com/project-sign-detection/traffic-sign-cdfml.

This dataset is part of [RF100](https://rf100.org), an [Intel-sponsored](https://www.intel.com/) initiative to create a new object detection benchmark for model generalizability.

Access the RF100 Github repo: https://github.com/roboflow-ai/roboflow-100-benchmark